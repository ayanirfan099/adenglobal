# Content notes

Confirmed: ADEN GLOBAL, Muhammad Imran Jamal and Najam Us Saqib as Managing Directors, Suleman Khan as CEO, Pakistan-based consultancy, phone/WhatsApp +923457777547, and the four specified services. These names and titles were supplied by the user. All active contact and enquiry links use the single published number.

Not published: reference-card email, exact office address, social accounts, domain ownership, career tenure, testimonials, success rates, accreditations, partnerships, work visa services, prices, hotel names or visa guarantees.

The site describes discussion topics, not promised availability or outcomes. Quotation scope, third-party charges, inclusions and cancellation terms must be confirmed before a commitment. No response time is promised.

The supplied logo artwork includes WORK in its tagline. The website frames its golden globe in CSS and uses the existing HTML wordmark with STUDY · TRAVEL · EXPLORE to match the authorised service scope. The original artwork is preserved unchanged in `branding/logo-original.png`; the web version is a web-optimised WebP export. The SVG remains only as a lightweight favicon.

The hero is an AI-generated illustrative landscape, not an advertised itinerary or a specific destination. All assets are local; no external fonts or images are requested at runtime.

The four service-card JPEGs are the original files supplied by the user in the uploaded ZIP. They are illustrative backgrounds, not a promise of a specific airport, institution, accommodation or package. The images are assigned by their visible content: airport, library, terrace and Makkah scene.

The About panel currently uses the supplied golden globe logo instead of the personal travel photo. The personal photo was removed from the current website files and exports at the user's request. The matching leadership blocks appear in this order: Suleman Khan (SK), CEO; Najam Us Saqib (NUS), Managing Director; Muhammad Imran Jamal (MIJ), Managing Director.

The requested black-and-gold palette continues through the header, service navigation, service cards, detailed service panels, About, enquiry process, FAQs, contact form and footer. Gold is used for emphasis and calls to action, with warm off-white text for readable body copy. Shared theme variables and overrides are labelled in styles.css.

No owned domain or domain-based email is assumed. Canonical and absolute social image URLs can be added after domain confirmation. No search ranking is promised.
